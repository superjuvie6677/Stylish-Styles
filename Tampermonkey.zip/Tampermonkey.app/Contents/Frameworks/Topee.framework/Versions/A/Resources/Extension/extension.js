require('../Common/polyfills');

var logging = require('../Background/logging');
logging.setup();

var eventEmitter = require('../Background/event-bus.js');
window.TopeeXMLHttpRequest = require('../Background/topee-xmlhttprequest.js');

var serviceEvents = [
    'xhr'
];

if (window.webkit && window.webkit.messageHandlers) {
    var manageRequest = function (payload) {
        if (payload.eventName === 'request') {
            chrome.runtime.onMessage._emit(payload.message, {
                id: 'topee',
                url: payload.url,
            }, sendResponse);
            return;
        }
        if (payload.eventName === 'response') {
            chrome.runtime.sendMessage._emit(payload);
            return;
        }

        if (serviceEvents.includes(payload.eventName)) {
            eventEmitter.emit(payload.eventName, payload);
        }

        function sendResponse(response) {
            window.webkit.messageHandlers.appex.postMessage({
                type: 'bg',
                tabId: payload.tabId,
                eventName: 'messageResponse',
                messageId: payload.messageId,
                payload: response
            });
        }
    };

    var runtime = require('../Background/chrome/runtime.js');
    runtime.sendMessage = function(message, responseCallback) {
        var messageId = Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);

        if (responseCallback) {
            eventEmitter.addListener('response', onResponse);
        }

        window.webkit.messageHandlers.appex.postMessage({
            type: 'bg',
            eventName: 'sendMessage',
            messageId: messageId,
            message: message
        });

        function onResponse(payload) {
            if (payload.messageId === messageId) {
                var p = payload.payload;
                if (!p && (p = payload.payload_json)) {
                    p = JSON.parse(p);
                }

                responseCallback(p);
                eventEmitter.removeListener('response', onResponse);
            }
        }
    };
    runtime.sendMessage._emit = function (payload) {
        eventEmitter.emit('response', payload);
    };

    window.chrome = {
        runtime: runtime,
        extension: require('../Background/chrome/extension.js'),
    };

    window.topee = {
        manageRequest: manageRequest
    };

    window.close = function() {
        window.webkit.messageHandlers.popup.postMessage({
            hide: true
        });
    };

    var resize_to, old_height, old_width;
    var updateSize = function() {
        if (resize_to) {
            resize_to = window.clearTimeout(resize_to);
        }
        resize_to = window.setTimeout(function() {
            var width = document.body.scrollWidth;
            var height = document.body.offsetHeight;

            if (width != old_width || height != old_height) {
                old_height = height;
                old_width = width;
                window.webkit.messageHandlers.popup.postMessage({
                    width: width,
                    height: height
                });
                window.setTimeout(updateSize, 300);
            }

            resize_to = null;
        }, 100);
    };

    window.addEventListener('load', function() {
        updateSize();
        var MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
        if (MutationObserver) {
            new MutationObserver(function() {
                updateSize();
            }).observe(document, {
                childList: true, attributes: true,
                characterData: true, subtree: true
            });
        } else {
            document.addEventListener("DOMSubtreeModified", updateSize);
        }
    });
} else {
    window.webkit = {
        messageHandlers: {
            appex: {
                postMessage: function(details) {
                    safari.extension.dispatchMessage(details.type, details);
                }
            },
            log: {
                postMessage: function(details) {
                    safari.extension.dispatchMessage(details.type, details);
                }
            }
        }
    };

    safari.self.addEventListener('message', function(event) {
        if (serviceEvents.includes(event.name)) {
            eventEmitter.emit(event.name, event.message);
        }
    });
}

