'use strict';

var eventEmitter = require('./event-bus.js');
var registry = {};

eventEmitter.addListener('xhr', function (payload) {
    var id, xhr;
    if ((id = payload.id) === undefined ||
        ((xhr = registry[id]) === undefined)) {
        return;
    }

    if (handle(xhr, payload)) {
        delete registry[id];
    }
});

function TopeeXMLHttpRequest() {
    this.id = Date.now() + (Math.random() + 1).toString(36).substring(7);
    registry[this.id] = this;
}

function handle(xhr, payload) {
    var data = payload.data;
    var send_progress = function() {
        var event = {
            total: xhr.total,
            loaded: xhr.loaded,
            lengthComputable: xhr.total !== undefined && xhr.total >= 0
        };
        if (xhr.onprogress) xhr.onprogress.apply(xhr, [ event ]);
    };

    if (data.readyState != xhr.readyState) {
        if (data.timeout) {
            // timout
            if (xhr.ontimeout) xhr.ontimeout.apply(xhr, []);
            return;
        }
        Object.assign(xhr, data);

        if (xhr.onreadystatechange) {
            xhr.onreadystatechange.apply(xhr, []);
        }
        if (data.readyState == 4) {
            var s = data.status;
            if (s >= 400) {
                if (xhr.onload) xhr.onload.apply(xhr, []);
            } else if (s >= 300) {
                // should never happen
            } else if (s >= 200) {
                if (xhr.onload) xhr.onload.apply(xhr, []);
            } else if (s >= 100) {
                // should never happen
            } else if (s === 0) {
                if (xhr.onerror) xhr.onerror.apply(xhr, []);
            } else {
                // should never happen
            }
            return true;
        } else if (data.readyState > 1) {
            if (data.readyState == 3) {
                if (xhr.onloadstart) xhr.onloadstart.apply(xhr, []);
            }
            send_progress();
        }
    } else if (data.readyState == 3) {
        Object.assign(xhr, data);
        send_progress();
    }

    return;
}

TopeeXMLHttpRequest.UNSENT              = 0;
TopeeXMLHttpRequest.OPENED              = 1;
TopeeXMLHttpRequest.HEADERS_RECEIVED    = 2;
TopeeXMLHttpRequest.LOADING             = 3;
TopeeXMLHttpRequest.DONE                = 4;

TopeeXMLHttpRequest.prototype.readyState    = TopeeXMLHttpRequest.UNSENT;
TopeeXMLHttpRequest.prototype.status        = 0;
TopeeXMLHttpRequest.prototype.statusText    = "";

var str2ab = function(str) {
    var ab = new window.Uint8Array(str.length);
    for (var i=0; i<str.length; i++) {
        ab[i] = str.charCodeAt(i) & 0xff;
    }
    return ab.buffer;
};

var Base64_decode = function(input) {
    return window.atob(input);
};

var UTF8_decode = function(s) {
    return window.decodeURIComponent(window.escape(s));
};

var UTF8_encode = function(s) {
    return window.unescape(window.encodeURIComponent(s));
};

var Base64_encode = function(input) {
    var binary = '';
    for (var i = 0; i < input.length; i++) {
        binary += window.String.fromCharCode(input.charCodeAt(i) & 0xff);
    }
    return window.btoa(binary);
};

var M = 16384;
var ab2str = function(arrayBuffer) {
    try {
        var r = '';
        var view = new window.Uint8Array(arrayBuffer);
        for (var i=0; i<view.length; i+=M) {
            r += window.String.fromCharCode.apply(null, view.subarray(i, i + M));
        }

        return r;
    } catch (e) {
        window.console.warn(e);
    }
    return null;
};

var blob2str = function(data, cb) {
    var reader = new FileReader();
    reader.onloadend = function() {
        cb(ab2str(this.result));
    };
    reader.onerror = reader.onabort = function(e) { cb(null, e || 'unknown error'); };
    reader.readAsArrayBuffer(data);
};

var convert = function(data, rt, ct) {
    var d;
    if (rt == 'arraybuffer') {
        d = str2ab(data);
    } else if (rt == 'blob') {
        d = new window.Blob([ str2ab(data) ], { type: ct });
    } else if (rt == 'json') {
        // JSON is UTF-encoded per spec
        d = JSON.parse(UTF8_decode(data));
    } else if (rt == 'document') {
        if (ct == 'text/xml') {
            var parser = new window.DOMParser();
            return parser.parseFromString(data, ct);
        } else {
            return null;
        }
    } else if (rt == 'text' || (ct && ct.match(/charset=(utf[-_]?8)/i))) {
        // assume UTF-8 encoding for all text content and UTF-8 charsets
        d = UTF8_decode(data);
    } else {
        d = data;
    }
    return d;
};

var converter = {
    response: function(data, r) {
        var rt = r.responseType ? r.responseType.toLowerCase() : '';
        var ct = 'binary/octet-stream';

        if (r) {
            ct = (r.headers ? r.headers['content-type'] : null) || ct;
        }
        return convert(data, rt, ct);
    },
    responseText: function(data) {
        return convert(data, 'text');
    },
    responseXML:function(data, r) {
        var ct = (r.headers ? r.headers['content-type'] : null) || '';
        return convert(data, 'document', ct.split(';')[0]);
    }
};

Object.keys(converter).forEach(function(k) {
    Object.defineProperty(TopeeXMLHttpRequest.prototype, k, {
        get: function() {
            try {
                var r = this.responseData;
                if (r === undefined) return null;
                var data = Base64_decode(r);
                return converter[k](data, this);
            } catch (e) {
                console.warn('TopeeXMLHttpRequest:', e);
                return null;
            }
        }
    });
});

TopeeXMLHttpRequest.onreadystatechange  = null;
TopeeXMLHttpRequest.onopen              = null;
TopeeXMLHttpRequest.onsend              = null;
TopeeXMLHttpRequest.onload              = null;
TopeeXMLHttpRequest.onprogress          = null;
TopeeXMLHttpRequest.onabort             = null;

TopeeXMLHttpRequest.prototype.open  = function(sMethod, sUrl, bAsync, sUser, sPassword) {
    this.method = sMethod;
    this.url = sUrl;
    this.async = true;
    this.user = sUser;
    this.password = sPassword;

    if (this.onopen) this.onopen.apply(this, []);
};
TopeeXMLHttpRequest.prototype.send  = function(vData) {
    if (this.mime_type) {
        if (!this.request_headers) this.request_headers = {};
        if (!this.request_headers['content-type']) {
            this.request_headers['content-type'] = this.mime_type;
        }
    }

    var details = {
        method: this.method,
        url: this.url,
        headers: this.request_headers,
        timeout: this.timeout
    };

    var that = this;
    var send = function() {
        window.webkit.messageHandlers.appex.postMessage({
            type: 'xhr',
            id: that.id,
            details: details
        });

        if (that.onsend) that.onsend.apply(that, []);
    };

    if (vData) {
        if (vData instanceof Blob) {
            blob2str(vData, function(data, error) {
                if (data === null || error) {
                    that.readyState = 0;
                    that.statusText = error || "data read error";
                    if (that.onerror) that.onerror.apply(that, []);
                } else {
                    details.data = Base64_encode(data);
                    send();
                }
            });
            return;
        } else {
            details.data = Base64_encode(UTF8_encode(vData));
        }
    }
    send();
};
TopeeXMLHttpRequest.prototype.abort = function() {
    this.canceled = true;
    delete registry[this.id];

    if (this.onabort) this.onabort.apply(this, []);
};

TopeeXMLHttpRequest.prototype.overrideMimeType = function(mime) {
    this.mime_type = mime;
};
TopeeXMLHttpRequest.prototype.getAllResponseHeaders = function() {
    var h = this.headers;
    return Object.keys(h).map(function(k) {
        return k + ':' + h[k];
    }).join('\r\n');
};
TopeeXMLHttpRequest.prototype.getResponseHeader = function(sName) {
    return this.headers[sName];
};
TopeeXMLHttpRequest.prototype.setRequestHeader  = function(sName, sValue) {
    if (!this.request_headers) this.request_headers = {};
    this.request_headers[sName.toLowerCase()] = sValue;
};
TopeeXMLHttpRequest.prototype.toString  = function() {
    return '[' + "object" + ' ' + "XMLHttpRequest" + ']';
};
TopeeXMLHttpRequest.toString    = function() {
    return '[' + "XMLHttpRequest" + ']';
};

module.exports = TopeeXMLHttpRequest;
